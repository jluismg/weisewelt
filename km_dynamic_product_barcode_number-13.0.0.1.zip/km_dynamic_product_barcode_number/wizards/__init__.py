from . import product_product_barcode
from . import product_template_barcode